
import express from "express";
import morgan from "morgan";
import cors from "cors";

import { rateLimit } from 'express-rate-limit'

import swaggerUi from "swagger-ui-express";
import {
  RouteDiscovery,
  SpecGenerator
} from "express-swagger-auto";

import { todoRouter } from "./routes/todoRouter.js";
import { authenticationRouter } from "./routes/authenticationRouter.js";
import { enforceAuthentication } from "./middleware/authorization.js";

const app = express();
const PORT = 3000;

// Global middleware
app.use(morgan("dev"));
app.use(cors());
app.use(express.json());

const limiter = rateLimit({
	windowMs: 60 * 1000, // 1 minute
	limit: 10, // Limit each IP to 10 requests per `window` (here, per 1 minute).
	standardHeaders: 'draft-8', // draft-6: `RateLimit-*` headers; draft-7 & draft-8: combined `RateLimit` header
	legacyHeaders: false, // Disable the `X-RateLimit-*` headers.
	ipv6Subnet: 56, // Set to 60 or 64 to be less aggressive, or 52 or 48 to be more aggressive
	// store: ... , // Redis, Memcached, etc. See below.
})

// Apply the rate limiting middleware to all requests.
app.use(limiter)

// Public documentation router
// Mounted before authentication to keep Swagger accessible
const documentationRouter = express.Router();
app.use(documentationRouter);

// --------------------------------------------------
// API v1
// --------------------------------------------------

const v1Router = express.Router();

// Public authentication routes
v1Router.use(authenticationRouter);

// Authentication required for subsequent routes
v1Router.use(enforceAuthentication);

// Protected to-do routes
v1Router.use(todoRouter);

// Mount the API under /api/v1
app.use("/api/v1", v1Router);

// --------------------------------------------------
// OpenAPI / Swagger
// --------------------------------------------------

const discovery = new RouteDiscovery();
const routes = discovery.discover(app);

const generator = new SpecGenerator({
  info: {
    title: "To-do List REST API",
    version: "1.0.0"
  },
  servers: [
    { url: `http://localhost:${PORT}` }
  ]
});

const spec = generator.generate(routes);

console.log("OpenAPI version:", spec.openapi);
console.log("Discovered paths:", Object.keys(spec.paths ?? {}));

// Raw OpenAPI specification
documentationRouter.get("/openapi.json", (req, res) => {
  res.json(spec);
});

// Interactive Swagger UI
documentationRouter.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(spec)
);

// --------------------------------------------------
// Error handling
// --------------------------------------------------

// Unknown endpoints
app.use((req, res) => {
  res.status(404).json({
    code: 404,
    description: "Endpoint not found"
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack || err);

  if (res.headersSent) {
    return next(err);
  }

  const status = err.status || err.statusCode || 500;

  res.status(status).json({
    code: status,
    description: err.message || "An error occurred"
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`REST API: http://localhost:${PORT}/api/v1`);
  console.log(`Swagger UI: http://localhost:${PORT}/api-docs`);
  console.log(`OpenAPI JSON: http://localhost:${PORT}/openapi.json`);
});
