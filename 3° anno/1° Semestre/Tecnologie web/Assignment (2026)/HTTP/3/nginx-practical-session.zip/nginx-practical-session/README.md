# Nginx practical session

Start the server:

```bash
docker compose up -d
```

Edit files under `website/` and reload the page; no image rebuild is needed.
After changing `nginx.conf`, restart the container:

```bash
docker compose restart nginx
```

Stop and remove the container:

```bash
docker compose down
```
